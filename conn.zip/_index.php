<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
	</head>
	<body>
			<?php
			include "../login/config.php";
			// $_SESSION['user_id'] = 1;
			loggedInCheck();
			?>
	</body>
</html>